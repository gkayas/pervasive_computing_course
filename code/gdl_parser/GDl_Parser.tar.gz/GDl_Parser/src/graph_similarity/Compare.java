package graph_similarity;

import java.util.ArrayList;


public class Compare{

    public static void comapreMatrix(Integer [][] matA, Integer[][] matB) {
        try {
           

            Graph graphA = new Graph(matA);
            Graph graphB = new Graph(matB);
           // Graph graphC = new Graph(graphCSource);

            NMSimilarity similarityMeasure = new NMSimilarity(graphA,graphB, 0.011);
            System.out.println("\nTwo graphs have " + similarityMeasure.getGraphSimilarity() + "% of similarity");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
