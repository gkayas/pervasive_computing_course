package parser;

import graph_similarity.Compare;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

import org.json.*;


public class Main {

	public static void main(String[] args) {
		if(args.length < 2) {
			System.out.println("Give gdl file name.");
			return;
		}

		if(args[0] == null || args[0].length()==0 || 
				args[1] == null || args[1].length()==0) {

			System.out.println("Wrong formatted gdl file name.");
			return;
		}
		
		extractAdjmat2( args[0]);
		extractAdjmat2( args[1]);

		//		String filePath1  = args[0];
		//		String filePath2  = args[1];
		//		
		//		GraphData data1 = extractAdjmat(filePath1);
		//		GraphData data2 = extractAdjmat(filePath2);
		//Hashtable<Integer, List<Integer>> adjTable1 = data1.adjTab;
		//Hashtable<Integer, List<Integer>> adjTable2 = data2.adjTab;

		//Compare.comapreMatrix(extractAdjmat2(filePath1), extractAdjmat2(filePath2));

		//JSONObject obj = new JSONObject(sb.toString());

		//String nodeCount = obj.getJSONObject("node:").getString("title");

		//System.out.println(nodeCount);
	}

	private static void extractAdjmat2( String filePath) {
		int nodeCount = 0;
		Integer [] [] adjMat;
		Hashtable<Integer, List<Integer>> adjTable = new Hashtable<Integer, List<Integer>>();

		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(filePath));
			String line;
			while ((line = br.readLine()) != null) {

				if(line.startsWith("node:") /*|| line.startsWith("edge:")*/) {
					nodeCount++;
				}

				if(line.startsWith("edge:") ) {
					line = line.substring(line.indexOf("{")+1);
					parseEdgeLine(line, adjTable);

				}
				//sb.append(line);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println(filePath+" File not found.");
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println(filePath+" read generates IOException.");
		}

		//		adjMat = new Integer[nodeCount][nodeCount];
		//		
		//		for(int i = 0 ; i< adjMat.length; i++) {
		//			for(int j = 0 ; i< adjMat.length; i++) {
		//				adjMat[i][j] = 0;
		//			}
		//		}

		//print the adjTable

		PrintWriter pwTable;
		try {
			pwTable = new PrintWriter(filePath+".adjTable");
			
			pwTable.append(nodeCount+"\n");
			
			for(int i = 0; i <nodeCount ; i++) {
				
				pwTable.append("1\n");
			}
			

			Enumeration<Integer> keys = adjTable.keys();

			while (keys.hasMoreElements()) {
				int source = keys.nextElement();
				//pwTable.append(source+ " : ");
				//System.out.print(source+ " : ");
				List<Integer> adjacents =  adjTable.get( source );
				for (Integer adjacent : adjacents) {

					pwTable.append(source+" "+adjacent+"\n");
					
				}
				
			}
			pwTable.flush();
			pwTable.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Number of nodes: "+nodeCount);
		//GraphData data = new GraphData();
		//data.adjTab = adjTable;
		//data.nodeCount = nodeCount;

		//return adjMat;
	}

	static void parseEdgeLine(String edgeLIne, Hashtable<Integer, List<Integer>> adjTable){

		String [] parts = edgeLIne.split(" ");

		/*
		 * At this point the value of edgeLine will be like below:
		 * " sourcename: "6586" targetname: "6582" }"
		 * That's why the parsing was done to extract sourcename and targetname 
		 */

		int source = Integer.parseInt(parts[2].replaceAll("\"", ""));
		int target = Integer.parseInt(parts[4].replaceAll("\"", ""));
		List<Integer> list = adjTable.get(source);

		if(null == list) {
			list = new ArrayList<Integer>();
			list.add(target);
			//adj
			adjTable.put(source, list);

		} else {
			list.add(target);
		}

	}

}

class GraphData{
	Hashtable<Integer, List<Integer>> adjTab;
	int nodeCount;
}
